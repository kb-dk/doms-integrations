
package dk.statsbiblioteket.doms.centralWebservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the dk.statsbiblioteket.doms.centralWebservice package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ModifyDatastream_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "modifyDatastream");
    private final static QName _AddFileFromPermanentURL_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "addFileFromPermanentURL");
    private final static QName _DeleteObjectResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "deleteObjectResponse");
    private final static QName _InvalidResourceException_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "InvalidResourceException");
    private final static QName _NewObject_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "newObject");
    private final static QName _GetFileObjectWithURLResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getFileObjectWithURLResponse");
    private final static QName _SetObjectLabel_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "setObjectLabel");
    private final static QName _MarkInProgressObject_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "markInProgressObject");
    private final static QName _GetLatestModifiedResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getLatestModifiedResponse");
    private final static QName _GetFileObjectWithURL_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getFileObjectWithURL");
    private final static QName _GetLatestModified_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getLatestModified");
    private final static QName _MarkInProgressObjectResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "markInProgressObjectResponse");
    private final static QName _GetDatastreamContentsResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getDatastreamContentsResponse");
    private final static QName _GetIDsModifiedResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getIDsModifiedResponse");
    private final static QName _GetDatastreamContents_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getDatastreamContents");
    private final static QName _AddFileResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "addFileResponse");
    private final static QName _DeleteObject_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "deleteObject");
    private final static QName _NewObjectResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "newObjectResponse");
    private final static QName _GetIDsModified_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getIDsModified");
    private final static QName _GetViewBundle_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getViewBundle");
    private final static QName _SetObjectLabelResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "setObjectLabelResponse");
    private final static QName _InvalidCredentialsException_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "InvalidCredentialsException");
    private final static QName _AddRelation_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "addRelation");
    private final static QName _MarkPublishedObjectResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "markPublishedObjectResponse");
    private final static QName _MethodFailedException_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "MethodFailedException");
    private final static QName _AddFile_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "addFile");
    private final static QName _ModifyDatastreamResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "modifyDatastreamResponse");
    private final static QName _AddFileFromPermanentURLResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "addFileFromPermanentURLResponse");
    private final static QName _MarkPublishedObject_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "markPublishedObject");
    private final static QName _AddRelationResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "addRelationResponse");
    private final static QName _GetViewBundleResponse_QNAME = new QName("http://central.doms.statsbiblioteket.dk/", "getViewBundleResponse");
    private final static QName _IdsModifiedLimit_QNAME = new QName("", "limit");
    private final static QName _IdsModifiedState_QNAME = new QName("", "state");
    private final static QName _IdsModifiedOffset_QNAME = new QName("", "offset");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: dk.statsbiblioteket.doms.centralWebservice
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ViewBundleWrapper }
     * 
     */
    public ViewBundleWrapper createViewBundleWrapper() {
        return new ViewBundleWrapper();
    }

    /**
     * Create an instance of {@link PidAndRelation }
     * 
     */
    public PidAndRelation createPidAndRelation() {
        return new PidAndRelation();
    }

    /**
     * Create an instance of {@link IdsModified }
     * 
     */
    public IdsModified createIdsModified() {
        return new IdsModified();
    }

    /**
     * Create an instance of {@link LatestModified }
     * 
     */
    public LatestModified createLatestModified() {
        return new LatestModified();
    }

    /**
     * Create an instance of {@link ListOfRelations }
     * 
     */
    public ListOfRelations createListOfRelations() {
        return new ListOfRelations();
    }

    /**
     * Create an instance of {@link Relation }
     * 
     */
    public Relation createRelation() {
        return new Relation();
    }

    /**
     * Create an instance of {@link URL }
     * 
     */
    public URL createURL() {
        return new URL();
    }

    /**
     * Create an instance of {@link PidFilenameChecksumUrlFormat }
     * 
     */
    public PidFilenameChecksumUrlFormat createPidFilenameChecksumUrlFormat() {
        return new PidFilenameChecksumUrlFormat();
    }

    /**
     * Create an instance of {@link Void }
     * 
     */
    public Void createVoid() {
        return new Void();
    }

    /**
     * Create an instance of {@link PidDSIDContents }
     * 
     */
    public PidDSIDContents createPidDSIDContents() {
        return new PidDSIDContents();
    }

    /**
     * Create an instance of {@link SinglePid }
     * 
     */
    public SinglePid createSinglePid() {
        return new SinglePid();
    }

    /**
     * Create an instance of {@link DatastreamProfile }
     * 
     */
    public DatastreamProfile createDatastreamProfile() {
        return new DatastreamProfile();
    }

    /**
     * Create an instance of {@link PidFileNameChecksumContents }
     * 
     */
    public PidFileNameChecksumContents createPidFileNameChecksumContents() {
        return new PidFileNameChecksumContents();
    }

    /**
     * Create an instance of {@link RecordDescription }
     * 
     */
    public RecordDescription createRecordDescription() {
        return new RecordDescription();
    }

    /**
     * Create an instance of {@link dk.statsbiblioteket.doms.centralWebservice.String }
     * 
     */
    public dk.statsbiblioteket.doms.centralWebservice.String createString() {
        return new dk.statsbiblioteket.doms.centralWebservice.String();
    }

    /**
     * Create an instance of {@link Pidlist }
     * 
     */
    public Pidlist createPidlist() {
        return new Pidlist();
    }

    /**
     * Create an instance of {@link PidAndName }
     * 
     */
    public PidAndName createPidAndName() {
        return new PidAndName();
    }

    /**
     * Create an instance of {@link ListRecordDescription }
     * 
     */
    public ListRecordDescription createListRecordDescription() {
        return new ListRecordDescription();
    }

    /**
     * Create an instance of {@link ViewBundle }
     * 
     */
    public ViewBundle createViewBundle() {
        return new ViewBundle();
    }

    /**
     * Create an instance of {@link Long }
     * 
     */
    public Long createLong() {
        return new Long();
    }

    /**
     * Create an instance of {@link Stringlist }
     * 
     */
    public Stringlist createStringlist() {
        return new Stringlist();
    }

    /**
     * Create an instance of {@link PidAndDSID }
     * 
     */
    public PidAndDSID createPidAndDSID() {
        return new PidAndDSID();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidDSIDContents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "modifyDatastream")
    public JAXBElement<PidDSIDContents> createModifyDatastream(PidDSIDContents value) {
        return new JAXBElement<PidDSIDContents>(_ModifyDatastream_QNAME, PidDSIDContents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidFilenameChecksumUrlFormat }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "addFileFromPermanentURL")
    public JAXBElement<PidFilenameChecksumUrlFormat> createAddFileFromPermanentURL(PidFilenameChecksumUrlFormat value) {
        return new JAXBElement<PidFilenameChecksumUrlFormat>(_AddFileFromPermanentURL_QNAME, PidFilenameChecksumUrlFormat.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "deleteObjectResponse")
    public JAXBElement<Void> createDeleteObjectResponse(Void value) {
        return new JAXBElement<Void>(_DeleteObjectResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "InvalidResourceException")
    public JAXBElement<java.lang.String> createInvalidResourceException(java.lang.String value) {
        return new JAXBElement<java.lang.String>(_InvalidResourceException_QNAME, java.lang.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SinglePid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "newObject")
    public JAXBElement<SinglePid> createNewObject(SinglePid value) {
        return new JAXBElement<SinglePid>(_NewObject_QNAME, SinglePid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SinglePid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getFileObjectWithURLResponse")
    public JAXBElement<SinglePid> createGetFileObjectWithURLResponse(SinglePid value) {
        return new JAXBElement<SinglePid>(_GetFileObjectWithURLResponse_QNAME, SinglePid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidAndName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "setObjectLabel")
    public JAXBElement<PidAndName> createSetObjectLabel(PidAndName value) {
        return new JAXBElement<PidAndName>(_SetObjectLabel_QNAME, PidAndName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pidlist }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "markInProgressObject")
    public JAXBElement<Pidlist> createMarkInProgressObject(Pidlist value) {
        return new JAXBElement<Pidlist>(_MarkInProgressObject_QNAME, Pidlist.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Long }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getLatestModifiedResponse")
    public JAXBElement<Long> createGetLatestModifiedResponse(Long value) {
        return new JAXBElement<Long>(_GetLatestModifiedResponse_QNAME, Long.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link URL }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getFileObjectWithURL")
    public JAXBElement<URL> createGetFileObjectWithURL(URL value) {
        return new JAXBElement<URL>(_GetFileObjectWithURL_QNAME, URL.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link LatestModified }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getLatestModified")
    public JAXBElement<LatestModified> createGetLatestModified(LatestModified value) {
        return new JAXBElement<LatestModified>(_GetLatestModified_QNAME, LatestModified.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "markInProgressObjectResponse")
    public JAXBElement<Void> createMarkInProgressObjectResponse(Void value) {
        return new JAXBElement<Void>(_MarkInProgressObjectResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link dk.statsbiblioteket.doms.centralWebservice.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getDatastreamContentsResponse")
    public JAXBElement<dk.statsbiblioteket.doms.centralWebservice.String> createGetDatastreamContentsResponse(dk.statsbiblioteket.doms.centralWebservice.String value) {
        return new JAXBElement<dk.statsbiblioteket.doms.centralWebservice.String>(_GetDatastreamContentsResponse_QNAME, dk.statsbiblioteket.doms.centralWebservice.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListRecordDescription }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getIDsModifiedResponse")
    public JAXBElement<ListRecordDescription> createGetIDsModifiedResponse(ListRecordDescription value) {
        return new JAXBElement<ListRecordDescription>(_GetIDsModifiedResponse_QNAME, ListRecordDescription.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidAndDSID }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getDatastreamContents")
    public JAXBElement<PidAndDSID> createGetDatastreamContents(PidAndDSID value) {
        return new JAXBElement<PidAndDSID>(_GetDatastreamContents_QNAME, PidAndDSID.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "addFileResponse")
    public JAXBElement<Void> createAddFileResponse(Void value) {
        return new JAXBElement<Void>(_AddFileResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link SinglePid }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "deleteObject")
    public JAXBElement<SinglePid> createDeleteObject(SinglePid value) {
        return new JAXBElement<SinglePid>(_DeleteObject_QNAME, SinglePid.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link dk.statsbiblioteket.doms.centralWebservice.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "newObjectResponse")
    public JAXBElement<dk.statsbiblioteket.doms.centralWebservice.String> createNewObjectResponse(dk.statsbiblioteket.doms.centralWebservice.String value) {
        return new JAXBElement<dk.statsbiblioteket.doms.centralWebservice.String>(_NewObjectResponse_QNAME, dk.statsbiblioteket.doms.centralWebservice.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link IdsModified }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getIDsModified")
    public JAXBElement<IdsModified> createGetIDsModified(IdsModified value) {
        return new JAXBElement<IdsModified>(_GetIDsModified_QNAME, IdsModified.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidAndName }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getViewBundle")
    public JAXBElement<PidAndName> createGetViewBundle(PidAndName value) {
        return new JAXBElement<PidAndName>(_GetViewBundle_QNAME, PidAndName.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "setObjectLabelResponse")
    public JAXBElement<Void> createSetObjectLabelResponse(Void value) {
        return new JAXBElement<Void>(_SetObjectLabelResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "InvalidCredentialsException")
    public JAXBElement<java.lang.String> createInvalidCredentialsException(java.lang.String value) {
        return new JAXBElement<java.lang.String>(_InvalidCredentialsException_QNAME, java.lang.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidAndRelation }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "addRelation")
    public JAXBElement<PidAndRelation> createAddRelation(PidAndRelation value) {
        return new JAXBElement<PidAndRelation>(_AddRelation_QNAME, PidAndRelation.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "markPublishedObjectResponse")
    public JAXBElement<Void> createMarkPublishedObjectResponse(Void value) {
        return new JAXBElement<Void>(_MarkPublishedObjectResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "MethodFailedException")
    public JAXBElement<java.lang.String> createMethodFailedException(java.lang.String value) {
        return new JAXBElement<java.lang.String>(_MethodFailedException_QNAME, java.lang.String.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link PidFileNameChecksumContents }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "addFile")
    public JAXBElement<PidFileNameChecksumContents> createAddFile(PidFileNameChecksumContents value) {
        return new JAXBElement<PidFileNameChecksumContents>(_AddFile_QNAME, PidFileNameChecksumContents.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "modifyDatastreamResponse")
    public JAXBElement<Void> createModifyDatastreamResponse(Void value) {
        return new JAXBElement<Void>(_ModifyDatastreamResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "addFileFromPermanentURLResponse")
    public JAXBElement<Void> createAddFileFromPermanentURLResponse(Void value) {
        return new JAXBElement<Void>(_AddFileFromPermanentURLResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Pidlist }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "markPublishedObject")
    public JAXBElement<Pidlist> createMarkPublishedObject(Pidlist value) {
        return new JAXBElement<Pidlist>(_MarkPublishedObject_QNAME, Pidlist.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Void }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "addRelationResponse")
    public JAXBElement<Void> createAddRelationResponse(Void value) {
        return new JAXBElement<Void>(_AddRelationResponse_QNAME, Void.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ViewBundleWrapper }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://central.doms.statsbiblioteket.dk/", name = "getViewBundleResponse")
    public JAXBElement<ViewBundleWrapper> createGetViewBundleResponse(ViewBundleWrapper value) {
        return new JAXBElement<ViewBundleWrapper>(_GetViewBundleResponse_QNAME, ViewBundleWrapper.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "limit", scope = IdsModified.class)
    public JAXBElement<Integer> createIdsModifiedLimit(Integer value) {
        return new JAXBElement<Integer>(_IdsModifiedLimit_QNAME, Integer.class, IdsModified.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "state", scope = IdsModified.class)
    public JAXBElement<java.lang.String> createIdsModifiedState(java.lang.String value) {
        return new JAXBElement<java.lang.String>(_IdsModifiedState_QNAME, java.lang.String.class, IdsModified.class, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Integer }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "", name = "offset", scope = IdsModified.class)
    public JAXBElement<Integer> createIdsModifiedOffset(Integer value) {
        return new JAXBElement<Integer>(_IdsModifiedOffset_QNAME, Integer.class, IdsModified.class, value);
    }

}
