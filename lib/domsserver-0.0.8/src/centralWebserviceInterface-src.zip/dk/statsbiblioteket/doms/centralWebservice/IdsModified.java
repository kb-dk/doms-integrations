
package dk.statsbiblioteket.doms.centralWebservice;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlElementRef;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for IdsModified complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="IdsModified">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="since" type="{http://www.w3.org/2001/XMLSchema}long"/>
 *         &lt;element name="collectionPid" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="viewAngle" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="state" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/>
 *         &lt;element name="offset" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *         &lt;element name="limit" type="{http://www.w3.org/2001/XMLSchema}int" minOccurs="0"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "IdsModified", propOrder = {
    "since",
    "collectionPid",
    "viewAngle",
    "state",
    "offset",
    "limit"
})
public class IdsModified {

    protected long since;
    @XmlElement(required = true)
    protected java.lang.String collectionPid;
    @XmlElement(required = true)
    protected java.lang.String viewAngle;
    @XmlElementRef(name = "state", type = JAXBElement.class)
    protected JAXBElement<java.lang.String> state;
    @XmlElementRef(name = "offset", type = JAXBElement.class)
    protected JAXBElement<Integer> offset;
    @XmlElementRef(name = "limit", type = JAXBElement.class)
    protected JAXBElement<Integer> limit;

    /**
     * Gets the value of the since property.
     * 
     */
    public long getSince() {
        return since;
    }

    /**
     * Sets the value of the since property.
     * 
     */
    public void setSince(long value) {
        this.since = value;
    }

    /**
     * Gets the value of the collectionPid property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getCollectionPid() {
        return collectionPid;
    }

    /**
     * Sets the value of the collectionPid property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setCollectionPid(java.lang.String value) {
        this.collectionPid = value;
    }

    /**
     * Gets the value of the viewAngle property.
     * 
     * @return
     *     possible object is
     *     {@link java.lang.String }
     *     
     */
    public java.lang.String getViewAngle() {
        return viewAngle;
    }

    /**
     * Sets the value of the viewAngle property.
     * 
     * @param value
     *     allowed object is
     *     {@link java.lang.String }
     *     
     */
    public void setViewAngle(java.lang.String value) {
        this.viewAngle = value;
    }

    /**
     * Gets the value of the state property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}
     *     
     */
    public JAXBElement<java.lang.String> getState() {
        return state;
    }

    /**
     * Sets the value of the state property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link java.lang.String }{@code >}
     *     
     */
    public void setState(JAXBElement<java.lang.String> value) {
        this.state = ((JAXBElement<java.lang.String> ) value);
    }

    /**
     * Gets the value of the offset property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getOffset() {
        return offset;
    }

    /**
     * Sets the value of the offset property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setOffset(JAXBElement<Integer> value) {
        this.offset = ((JAXBElement<Integer> ) value);
    }

    /**
     * Gets the value of the limit property.
     * 
     * @return
     *     possible object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public JAXBElement<Integer> getLimit() {
        return limit;
    }

    /**
     * Sets the value of the limit property.
     * 
     * @param value
     *     allowed object is
     *     {@link JAXBElement }{@code <}{@link Integer }{@code >}
     *     
     */
    public void setLimit(JAXBElement<Integer> value) {
        this.limit = ((JAXBElement<Integer> ) value);
    }

}
