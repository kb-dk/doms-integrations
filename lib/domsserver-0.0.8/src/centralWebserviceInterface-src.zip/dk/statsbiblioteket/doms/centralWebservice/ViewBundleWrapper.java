
package dk.statsbiblioteket.doms.centralWebservice;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>Java class for viewBundleWrapper complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType name="viewBundleWrapper">
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="viewBundle" type="{http://central.doms.statsbiblioteket.dk/}ViewBundle"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "viewBundleWrapper", propOrder = {
    "viewBundle"
})
public class ViewBundleWrapper {

    @XmlElement(required = true)
    protected ViewBundle viewBundle;

    /**
     * Gets the value of the viewBundle property.
     * 
     * @return
     *     possible object is
     *     {@link ViewBundle }
     *     
     */
    public ViewBundle getViewBundle() {
        return viewBundle;
    }

    /**
     * Sets the value of the viewBundle property.
     * 
     * @param value
     *     allowed object is
     *     {@link ViewBundle }
     *     
     */
    public void setViewBundle(ViewBundle value) {
        this.viewBundle = value;
    }

}
